# NOXPLAY — Android redesign direction

Brand concept: cinematic media player with a dark, immersive canvas and restrained neon accents.

- Brand name: NOXPLAY (working name; verify trademark and package/distribution requirements before release).
- Palette: midnight ink `#080A12`, raised surface `#191F31`, electric violet `#8B5CF6`, cyan `#22D3EE`, soft white `#F7F7FC`.
- App icon: custom geometric play mark on a midnight violet/cyan gradient.
- Typography: retain Android's robust system font fallback for compatibility; use clear hierarchy, readable contrast, and consistent spacing as screens are refined.
- UX goals: preserve media playback and library behavior; favor clarity over excessive blur; keep motion short and purposeful.

This is an initial branding/theme pass on the supplied VLC for Android source tree, not a claim that every screen has been fully redesigned or that a release APK has been built. The project retains its upstream licensing files; review GPL and VLC trademark requirements before redistributing a modified build.
