@rem Gradle start up script for Windows
@if "%DEBUG%"=="" @echo off
@setlocal
set DIRNAME=%~dp0
if "%DIRNAME%"=="" set DIRNAME=.
@set CLASSPATH=%DIRNAME%\gradle\wrapper\gradle-wrapper.jar
@java -cp "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*
@endlocal
