# NK PLAYER — Ultimate Next-Generation Audio & Video Player

Premium Glassmorphism + Neon universal media player for Android.

## Features
- **Universal playback** via Media3/ExoPlayer (MP4/MKV/AVI/MOV/WebM/MP3/FLAC/WAV/OGG/M4A + H264/HEVC/AV1/VP9 where device supports)
- **Home Dashboard**: recent, continue watching, stats, search, grid/list
- **Video Player**: ExoPlayer, gestures, speed 0.5–2x, PiP, orientation lock, seek, volume, immersive fullscreen
- **Audio Player**: artwork, controls, shuffle/repeat, visualizer, EQ scaffold (AudioEffect)
- **Library**: MediaStore video+audio, folders, sort (date/name/size/duration), search
- **Subtitles**: SRT/ASS/VTT detection + ExoPlayer subtitle configs, delay/mime handling
- **Network**: HTTP(S)/HLS/DASH, RTSP/RTMP (engine-dependent), M3U/M3U8 parsing, SMB/NAS/DLNA scaffold
- **Studio**: 8 neon themes, glass/glow/AMOLED, live preview, persist via DataStore
- **Settings**: 16 sections with search + Studio shortcut
- **Premium**: SleepTimer, Visualizer, PlaybackService+MediaSession, Room history/favorites/playlists/bookmarks, diagnostics

## Architecture
- Kotlin + Jetpack Compose + Material3
- MVVM + Hilt + Room + DataStore + MediaStore + Media3
- `data/local/db` (Room), `data/local/datastore`, `data/local/mediastore`, `data/repository`
- `playback/PlaybackService` (MediaSessionService) + `PlayerManager` (MediaController)
- `ui/theme` (Neon palettes + Glassmorphism), `ui/home|player|library|studio|settings|components`

## Build (GitHub Actions)
Push to `main` — workflow `.github/workflows/build.yml` builds **debug + release APKs** (JDK 17, AGP 8.5.2, compileSdk 34, minSdk 24).

Local:
```bash
./gradlew assembleDebug
# APK at app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease
```

> SDK is provisioned by `android-actions/setup-android@v3` on CI. Locally set `ANDROID_HOME` or `sdk.dir` in `local.properties`.

## Permissions
READ_MEDIA_VIDEO/AUDIO/IMAGES (or READ_EXTERNAL_STORAGE <33), FOREGROUND_SERVICE_MEDIA_PLAYBACK, POST_NOTIFICATIONS, INTERNET, MODIFY_AUDIO_SETTINGS, USE_BIOMETRIC.

## What requires device/extra setup
- HW decode / specific codecs depend on device SoC
- SMB/NAS needs network + optional jcifs-ng integration
- DLNA/UPnP discovery scaffold — real impl needs Cling/Upnp lib + LAN permission
- Chromecast/AirPlay/DRM NOT claimed (needs proprietary SDKs/licenses)
- EQ/Bass/Virtualizer depend on device AudioEffect support — gracefully degraded, never faked as Atmos/DTS

## Honest Limitations
- No fake Dolby/DTS/bit-perfect claims
- Subtitle online search is scaffold (no key hardcoded, no silent upload)
- AI features (auto-sub, translation, chapter detect) are planned; not faked as done
- Format support = what Media3 + device decoders actually support (tested list in spec), graceful errors for unsupported/corrupt/DRM

## Project Structure
```
app/src/main/java/com/nkplayer/
  MainActivity.kt, NKApplication.kt
  data/{model, repository, local/{db, datastore, mediastore}}
  playback/ (PlaybackService, PlayerManager)
  ui/{theme, navigation, components, home, player, library, studio, settings}
  network/, subtitle/, equalizer/, util/
app/src/main/res/ (Glassmorphism drawables, adaptive icon, themes)
gradle/libs.versions.toml, build.gradle.kts, settings.gradle.kts
.github/workflows/build.yml
```

## License
Source is provided for building/testing. Respect codec licenses (FFmpeg/LibVLC if you add them) and Media3 license.

---

## Test Plan (manual)
- [ ] Fresh install → permission prompt → Videos/Music load via MediaStore
- [ ] Search filters both tabs live
- [ ] Tap video → fullscreen ExoPlayer → play/pause, ±10s, seek, speed chips, rotation, lock, PiP
- [ ] Audio screen → play/pause, shuffle, repeat, visualizer animates when playing
- [ ] Library → Tabs (Videos/Music/Folders), sort chips, folder grouping
- [ ] Studio → switch 8 themes, glass/glow sliders, AMOLED toggle, Apply & Back persists
- [ ] Settings → search filters sections, Studio shortcut
- [ ] Network URL via `NetworkDataSource.buildMediaItem` (HLS/DASH handling)
- [ ] Subtitle: attach local .srt beside video folder, verify with ExoPlayer subtitle config
- [ ] Background playback + notification via PlaybackService (foregroundServiceType mediaPlayback)

## Release Build Instructions
1. Generate keystore (once):
   ```bash
   keytool -genkey -v -keystore nk-player.jks -keyalg RSA -keysize 2048 -validity 10000 -alias nkplayer
   ```
2. Create `keystore.properties` (DO NOT commit):
   ```
   storeFile=/path/nk-player.jks
   storePassword=***
   keyAlias=nkplayer
   keyPassword=***
   ```
3. In `app/build.gradle.kts` add `signingConfigs` reading that file (template below), then:
   ```bash
   ./gradlew assembleRelease
   # APK: app/build/outputs/apk/release/app-release.apk
   ./gradlew bundleRelease
   # AAB: app/build/outputs/bundle/release/app-release.aab
   ```

## Signing template (add inside `android {}`)
```kotlin
val ksProps = java.util.Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) load(f.inputStream())
}
signingConfigs {
    create("release") {
        storeFile = ksProps["storeFile"]?.let { file(it.toString()) }
        storePassword = ksProps["storePassword"] as? String
        keyAlias = ksProps["keyAlias"] as? String
        keyPassword = ksProps["keyPassword"] as? String
    }
}
buildTypes {
    release {
        signingConfig = signingConfigs.getByName("release")
        isMinifyEnabled = true
        isShrinkResources = true
        proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
    }
}
```

## APK Size & Performance Notes
- Uses R8 + shrinkResources for release
- Coil + lazy grids + MediaStore pagination-friendly
- Glassmorphism uses simple alpha + BorderStroke (no expensive blur on low-RAM — add RenderEffect blur only when `ActivityManager.isLowRamDevice==false`)
- ExoPlayer HW decode by default, SW fallback via device

## Licenses & Attribution
- AndroidX Media3 — Apache-2.0
- Coil, Room, DataStore, Hilt — Apache-2.0
- ExoPlayer HLS/DASH extensions — Apache-2.0
