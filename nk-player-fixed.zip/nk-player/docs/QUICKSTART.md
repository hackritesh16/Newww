# Quickstart

## GitHub → APK (no local setup)
1. Create new repo on GitHub (empty).
2. Upload this zip's contents (or `git init; git add .; git commit -m init; git remote add origin <url>; git push -u origin main`).
3. Go to Actions tab → workflow "Build NK Player APK" runs automatically → download `nk-player-debug-apk` + `nk-player-release-apk` artifacts.

## Local build
```bash
unzip nk-player.zip
cd nk-player
./gradlew assembleDebug
adb install app/build/outputs/apk/debug/app-debug.apk
```

## First run checklist
- Grant media permissions when prompted.
- Add some MP4/MP3 files to device storage (Downloads/Movies/Music).
- Open Library → verify Videos/Music/Folders populate.
- Open Studio → try Synthwave + AMOLED off → Apply.

## Adding network streams
Use any HTTP/HLS/DASH URL via:
```kotlin
val item = NetworkDataSource.buildMediaItem("https://example.com/stream.m3u8", "My Stream")
playerManager.getController()?.setMediaItem(item)
```
M3U import: `NetworkDataSource.parseM3U(m3uText)` → list of URLs.

## Subtitles
Place `movie.srt` next to `movie.mp4` → `SubtitleManager.findLocalSubs` finds it → pass to `SubtitleManager.buildMediaItemWithSubs` for ExoPlayer.

## EQ
`EqualizerHelper(audioSessionId)` wraps Android AudioEffect. Guard with `init()` success; not all devices expose EQ — app degrades gracefully.
