# NK Player Architecture

## Layers
- **UI** (Compose + Material3): `ui/theme`, `ui/components` (GlassCard, Visualizer), `ui/navigation` (NavHost), screens: `home`, `player` (Video+Audio), `library`, `studio`, `settings`.
- **Playback**: `PlaybackService` (MediaSessionService, ExoPlayer, AudioAttributes, foregroundServiceType=mediaPlayback) + `PlayerManager` (MediaController, StateFlows). Media3 handles HLS/DASH/RTSP via extensions.
- **Data**: `mediastore/MediaStoreHelper` (Video/Audio queries), `db/NKDatabase` (History/Favorites/Playlists/Bookmarks), `datastore/PreferencesManager` (themes, skip, speed, shuffle...), `repository/MediaRepository`.
- **DI**: `di/AppModule` (Room singleton).
- **Extras**: `network/NetworkDataSource`, `subtitle/SubtitleManager`, `equalizer/EqualizerHelper` (AudioEffect), `util/SleepTimer`, `util/Diagnostics`.

## Why Media3/ExoPlayer over LibVLC?
- Stable AGP 8.5.2 + Kotlin 1.9.22 compat, APK size smaller than bundled LibVLC, HLS/DASH/RTSP via official extensions, MediaSession built-in, no native ABI headaches on CI. LibVLC can be swapped by replacing `PlaybackService` player creation if you need extra codec coverage — interface is isolated.

## Theme System
`ui/theme/Color.kt` defines 8 Neon palettes. `ThemeState` is runtime holder; `PreferencesManager` persists `theme_name/theme_mode/glass_alpha/glow` to DataStore. Studio screen edits ThemeState + writes to DataStore so theme survives restarts without rebuilding app.

## Performance Choices
- LazyVerticalGrid / LazyColumn with keys
- No RenderScript blur on low-RAM devices
- Room flows for history; MediaStore loaded on IO dispatcher with `withContext(Dispatchers.IO)`
- R8 + shrinkResources for release
