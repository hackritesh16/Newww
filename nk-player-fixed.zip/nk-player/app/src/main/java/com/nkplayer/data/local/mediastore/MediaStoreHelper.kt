package com.nkplayer.data.local.mediastore

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.nkplayer.data.model.MediaItem
import com.nkplayer.data.model.MediaType
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MediaStoreHelper @Inject constructor(@ApplicationContext private val ctx: Context){
    suspend fun loadVideos(): List<MediaItem> = withContext(Dispatchers.IO){
        val list = mutableListOf<MediaItem>()
        val uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.TITLE, MediaStore.Video.Media.DURATION, MediaStore.Video.Media.SIZE, MediaStore.Video.Media.DATE_ADDED, MediaStore.Video.Media.MIME_TYPE, MediaStore.Video.Media.DATA, MediaStore.Video.Media.WIDTH, MediaStore.Video.Media.HEIGHT)
        ctx.contentResolver.query(uri, proj, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use{ c->
            val idIdx=c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameIdx=c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val titleIdx=c.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
            val durIdx=c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val sizeIdx=c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            val dateIdx=c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
            val mimeIdx=c.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
            val dataIdx=c.getColumnIndex(MediaStore.Video.Media.DATA)
            val wIdx=c.getColumnIndex(MediaStore.Video.Media.WIDTH)
            val hIdx=c.getColumnIndex(MediaStore.Video.Media.HEIGHT)
            while(c.moveToNext()){
                val id=c.getLong(idIdx)
                list.add(MediaItem(id=id, uri=ContentUris.withAppendedId(uri,id), displayName=c.getString(nameIdx)?: "Video $id", title=c.getString(titleIdx)?: c.getString(nameIdx)?: "Video $id", durationMs=c.getLong(durIdx), sizeBytes=c.getLong(sizeIdx), dateAdded=c.getLong(dateIdx), mimeType=c.getString(mimeIdx), path= runCatching{ c.getString(dataIdx)}.getOrNull(), type=MediaType.VIDEO, width= if(wIdx>=0) c.getInt(wIdx) else 0, height= if(hIdx>=0) c.getInt(hIdx) else 0, folder= runCatching{ c.getString(dataIdx)?.substringBeforeLast("/")?.substringAfterLast("/")}.getOrNull()))
            }
        }
        list
    }
    suspend fun loadAudios(): List<MediaItem> = withContext(Dispatchers.IO){
        val list= mutableListOf<MediaItem>()
        val uri= MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj= arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.SIZE, MediaStore.Audio.Media.DATE_ADDED, MediaStore.Audio.Media.MIME_TYPE, MediaStore.Audio.Media.DATA)
        val sel="${MediaStore.Audio.Media.IS_MUSIC} != 0"
        ctx.contentResolver.query(uri, proj, sel, null, "${MediaStore.Audio.Media.DATE_ADDED} DESC")?.use{ c->
            val idIdx=c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val nameIdx=c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val titleIdx=c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistIdx=c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumIdx=c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdIdx=c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durIdx=c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val sizeIdx=c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val dateIdx=c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val mimeIdx=c.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
            val dataIdx=c.getColumnIndex(MediaStore.Audio.Media.DATA)
            while(c.moveToNext()){
                val id=c.getLong(idIdx)
                val albumId=c.getLong(albumIdIdx)
                val artUri= ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)
                list.add(MediaItem(id=id, uri=ContentUris.withAppendedId(uri,id), displayName=c.getString(nameIdx)?: "Track $id", title=c.getString(titleIdx)?: c.getString(nameIdx)?: "Track $id", artist=c.getString(artistIdx), album=c.getString(albumIdx), albumId=albumId, durationMs=c.getLong(durIdx), sizeBytes=c.getLong(sizeIdx), dateAdded=c.getLong(dateIdx), mimeType=c.getString(mimeIdx), path=runCatching{c.getString(dataIdx)}.getOrNull(), type=MediaType.AUDIO, artworkUri=artUri))
            }
        }
        list
    }
    fun resolveNetworkUri(url: String): Uri = Uri.parse(url)
}
