package com.nkplayer.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.nkplayer.ui.home.HomeScreen
import com.nkplayer.ui.library.LibraryScreen
import com.nkplayer.ui.player.AudioPlayerScreen
import com.nkplayer.ui.player.VideoPlayerScreen
import com.nkplayer.ui.settings.SettingsScreen
import com.nkplayer.ui.studio.StudioScreen

sealed class Route(val route: String){
    data object Home: Route("home")
    data object Library: Route("library")
    data object VideoPlayer: Route("video/{uri}"){
        fun withUri(u:String) = "video/${java.net.URLEncoder.encode(u,"UTF-8")}"
    }
    data object AudioPlayer: Route("audio")
    data object Studio: Route("studio")
    data object Settings: Route("settings")
}

@Composable
fun NKNavHost(){
    val nav = rememberNavController()
    NavHost(navController=nav, startDestination=Route.Home.route){
        composable(Route.Home.route){ HomeScreen(nav) }
        composable(Route.Library.route){ LibraryScreen(nav) }
        composable(Route.VideoPlayer.route){ backStack->
            val enc = backStack.arguments?.getString("uri")?:""
            val uri = java.net.URLDecoder.decode(enc,"UTF-8")
            VideoPlayerScreen(nav, uri)
        }
        composable(Route.AudioPlayer.route){ AudioPlayerScreen(nav) }
        composable(Route.Studio.route){ StudioScreen(nav) }
        composable(Route.Settings.route){ SettingsScreen(nav) }
    }
}
