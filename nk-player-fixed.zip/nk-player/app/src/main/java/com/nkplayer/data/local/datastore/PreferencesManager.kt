package com.nkplayer.data.local.datastore

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

val Context.dataStore by preferencesDataStore(name="nk_prefs")
enum class ThemeMode{ DARK, AMOLED, LIGHT }
enum class RepeatMode{ OFF, ONE, ALL }
enum class AspectRatio{ FIT, FILL, CROP, STRETCH, RATIO_16_9, RATIO_4_3 }

@Singleton
class PreferencesManager @Inject constructor(@ApplicationContext private val ctx: Context){
    private val THEME_NAME = stringPreferencesKey("theme_name")
    private val THEME_MODE = stringPreferencesKey("theme_mode")
    private val GLASS_ALPHA = floatPreferencesKey("glass_alpha")
    private val GLOW = floatPreferencesKey("glow")
    private val CORNER = intPreferencesKey("corner")
    private val REPEAT = stringPreferencesKey("repeat")
    private val SHUFFLE = booleanPreferencesKey("shuffle")
    private val SPEED = floatPreferencesKey("speed")
    private val SKIP_MS = intPreferencesKey("skip_ms")
    private val BRIGHTNESS = floatPreferencesKey("brightness")
    private val VOLUME = floatPreferencesKey("volume")
    private val SUB_SIZE = floatPreferencesKey("sub_size")
    private val SUB_DELAY = longPreferencesKey("sub_delay")
    private val EQ_ENABLED = booleanPreferencesKey("eq_enabled")
    private val EQ_PRESET = stringPreferencesKey("eq_preset")
    private val SLEEP_MIN = intPreferencesKey("sleep_min")
    private val ASPECT = stringPreferencesKey("aspect")
    private val PIP = booleanPreferencesKey("pip")
    private val BG_PLAY = booleanPreferencesKey("bg_play")

    val themeName: Flow<String> = ctx.dataStore.data.map{ it[THEME_NAME] ?: "NeonBlue" }
    val themeMode: Flow<String> = ctx.dataStore.data.map{ it[THEME_MODE] ?: "AMOLED" }
    val glassAlpha: Flow<Float> = ctx.dataStore.data.map{ it[GLASS_ALPHA] ?: 0.12f }
    val glow: Flow<Float> = ctx.dataStore.data.map{ it[GLOW] ?: 0.6f }
    val skipMs: Flow<Int> = ctx.dataStore.data.map{ it[SKIP_MS] ?: 10000 }
    val speed: Flow<Float> = ctx.dataStore.data.map{ it[SPEED] ?: 1f }
    val shuffle: Flow<Boolean> = ctx.dataStore.data.map{ it[SHUFFLE] ?: false }
    val repeat: Flow<String> = ctx.dataStore.data.map{ it[REPEAT] ?: "OFF" }
    val eqEnabled: Flow<Boolean> = ctx.dataStore.data.map{ it[EQ_ENABLED] ?: false }

    suspend fun setThemeName(v:String){ ctx.dataStore.edit{ it[THEME_NAME]=v } }
    suspend fun setThemeMode(v:String){ ctx.dataStore.edit{ it[THEME_MODE]=v } }
    suspend fun setGlassAlpha(v:Float){ ctx.dataStore.edit{ it[GLASS_ALPHA]=v } }
    suspend fun setGlow(v:Float){ ctx.dataStore.edit{ it[GLOW]=v } }
    suspend fun setSkipMs(v:Int){ ctx.dataStore.edit{ it[SKIP_MS]=v } }
    suspend fun setSpeed(v:Float){ ctx.dataStore.edit{ it[SPEED]=v } }
    suspend fun setShuffle(v:Boolean){ ctx.dataStore.edit{ it[SHUFFLE]=v } }
}
