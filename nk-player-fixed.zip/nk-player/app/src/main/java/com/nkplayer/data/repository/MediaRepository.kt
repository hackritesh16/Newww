package com.nkplayer.data.repository

import com.nkplayer.data.local.db.dao.*
import com.nkplayer.data.local.db.entity.HistoryEntity
import com.nkplayer.data.local.mediastore.MediaStoreHelper
import com.nkplayer.data.model.MediaItem
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MediaRepository @Inject constructor(
    private val store: MediaStoreHelper,
    private val historyDao: HistoryDao,
    private val favDao: FavoriteDao,
    private val playlistDao: PlaylistDao,
){
    suspend fun videos(): List<MediaItem> = store.loadVideos()
    suspend fun audios(): List<MediaItem> = store.loadAudios()

    fun recentHistory(limit:Int=20): Flow<List<HistoryEntity>> = historyDao.recent(limit)
    suspend fun markPlayed(item: MediaItem, posMs: Long){
        historyDao.upsert(HistoryEntity(mediaId=item.id, title=item.title, artist=item.artist, uri=item.uri.toString(), type=item.type.name, lastPositionMs=posMs, durationMs=item.durationMs))
    }
    fun favorites() = favDao.all()
    suspend fun toggleFavorite(id:Long){
        if(favDao.isFav(id)) favDao.remove(id) else favDao.add(com.nkplayer.data.local.db.entity.FavoriteEntity(id))
    }
    fun playlists() = playlistDao.playlists()
}
