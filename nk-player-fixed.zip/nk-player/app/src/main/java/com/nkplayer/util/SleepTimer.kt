package com.nkplayer.util

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

object SleepTimer {
    private var job: Job? = null
    private val _remainingSec = MutableStateFlow<Int?>(null)
    val remainingSec: StateFlow<Int?> = _remainingSec

    fun start(minutes:Int, scope: CoroutineScope, onFinish:()->Unit){
        cancel()
        val total = minutes*60
        _remainingSec.value = total
        job = scope.launch{
            var left = total
            while(left>0){ delay(1000); left--; _remainingSec.value=left }
            _remainingSec.value=null
            onFinish()
        }
    }
    fun cancel(){ job?.cancel(); job=null; _remainingSec.value=null }
}
