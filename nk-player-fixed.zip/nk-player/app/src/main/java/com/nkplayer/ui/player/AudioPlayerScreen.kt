package com.nkplayer.ui.player

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.nkplayer.ui.components.AudioVisualizer
import com.nkplayer.ui.components.GlassCard
import com.nkplayer.ui.theme.*

@Composable
fun AudioPlayerScreen(nav: NavController){
    var isPlaying by remember{ mutableStateOf(false)}
    var progress by remember{ mutableStateOf(0.32f)}
    var shuffle by remember{ mutableStateOf(false)}
    var repeat by remember{ mutableStateOf(0)} //0 off 1 one 2 all
    val palette = ThemeState.palette

    Box(modifier=Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(BgBlack, BgSurface, palette.primary.copy(alpha=0.08f))))){
        Column(modifier=Modifier.fillMaxSize().padding(20.dp), verticalArrangement=Arrangement.SpaceBetween){
            Row(modifier=Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically){
                IconButton(onClick={ nav.popBackStack()}){ Icon(Icons.Filled.ArrowBack, null, tint=TextPrimary)}
                Text("Now Playing", style=MaterialTheme.typography.titleMedium)
                IconButton(onClick={}){ Icon(Icons.Filled.MoreVert, null, tint=TextSecondary)}
            }

            Column(horizontalAlignment=Alignment.CenterHorizontally, modifier=Modifier.fillMaxWidth(), verticalArrangement=Arrangement.spacedBy(16.dp)){
                // Artwork
                Box(modifier=Modifier.size(260.dp).clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(palette.primary, palette.secondary))), contentAlignment=Alignment.Center){
                    Icon(Icons.Filled.MusicNote, null, tint=Color.White.copy(alpha=0.9f), modifier=Modifier.size(80.dp))
                }
                Text("NK Audio Experience", style=MaterialTheme.typography.titleLarge, maxLines=1)
                Text("Unknown Artist  •  NK Player", style=MaterialTheme.typography.bodySmall.copy(color=TextSecondary))
                AudioVisualizer(isPlaying= isPlaying, color=palette.primary, modifier=Modifier.fillMaxWidth())
            }

            Column(verticalArrangement=Arrangement.spacedBy(12.dp)){
                Slider(value=progress, onValueChange={ progress=it }, colors=SliderDefaults.colors(activeTrackColor=palette.primary, thumbColor=palette.primary))
                Row(modifier=Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween){
                    Text("01:24", style=MaterialTheme.typography.labelSmall)
                    Text("03:45", style=MaterialTheme.typography.labelSmall)
                }
                Row(modifier=Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceEvenly, verticalAlignment=Alignment.CenterVertically){
                    IconButton(onClick={ shuffle=!shuffle}){ Icon(Icons.Filled.Shuffle, null, tint= if(shuffle) palette.primary else TextSecondary)}
                    IconButton(onClick={}, modifier=Modifier.size(48.dp).clip(CircleShape).background(BgSurface2)){ Icon(Icons.Filled.SkipPrevious, null, tint=TextPrimary, modifier=Modifier.size(28.dp))}
                    IconButton(onClick={ isPlaying=!isPlaying}, modifier=Modifier.size(72.dp).clip(CircleShape).background(palette.primary)){
                        Icon(if(isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint=Color.White, modifier=Modifier.size(36.dp))
                    }
                    IconButton(onClick={}, modifier=Modifier.size(48.dp).clip(CircleShape).background(BgSurface2)){ Icon(Icons.Filled.SkipNext, null, tint=TextPrimary, modifier=Modifier.size(28.dp))}
                    IconButton(onClick={ repeat=(repeat+1)%3}){
                        Icon(when(repeat){1-> Icons.Filled.RepeatOne else-> Icons.Filled.Repeat}, null, tint= if(repeat!=0) palette.primary else TextSecondary)
                    }
                }
                // EQ teaser
                GlassCard(modifier=Modifier.fillMaxWidth(), corner=16.dp){
                    Row(modifier=Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically){
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp), verticalAlignment=Alignment.CenterVertically){
                            Icon(Icons.Filled.Equalizer, null, tint=palette.primary)
                            Text("Equalizer", style=MaterialTheme.typography.titleSmall)
                        }
                        Switch(checked=false, onCheckedChange={})
                    }
                    Text("10-band EQ • Bass Boost • Virtualizer — Media3 + device AudioEffect", style=MaterialTheme.typography.labelSmall.copy(color=TextSecondary))
                }
            }
        }
    }
}
