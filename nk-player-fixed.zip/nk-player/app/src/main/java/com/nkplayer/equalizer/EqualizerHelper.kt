package com.nkplayer.equalizer

import android.media.audiofx.Equalizer
import android.media.audiofx.BassBoost
import android.media.audiofx.Virtualizer

/**
 * Wraps Android AudioEffect Equalizer. Requires audioSessionId from ExoPlayer.
 * Gracefully degrades if device does not support effects — never claims fake Atmos/DTS.
 */
class EqualizerHelper(private val sessionId: Int){
    private var eq: Equalizer? = null
    private var bass: BassBoost? = null
    private var virt: Virtualizer? = null

    fun init(): Boolean = try{
        eq = Equalizer(0, sessionId).also{ it.enabled=true }
        true
    }catch(e:Exception){ false }

    fun bandCount(): Int = try{ eq?.numberOfBands?.toInt() ?: 0 }catch(e:Exception){ 0 }
    fun setBandLevel(band: Int, level: Short){ try{ eq?.setBandLevel(band.toShort(), level)}catch(e:Exception){} }
    fun presets(): List<String> = try{ (0 until (eq?.numberOfPresets?.toInt() ?: 0)).map{ eq!!.getPresetName(it.toShort()) } }catch(e:Exception){ emptyList() }
    fun usePreset(idx:Int){ try{ eq?.usePreset(idx.toShort())}catch(e:Exception){} }
    fun setBassBoost(strength: Short){ try{ if(bass==null) bass=BassBoost(0,sessionId); bass?.setStrength(strength); bass?.enabled=true }catch(e:Exception){} }
    fun setVirtualizer(strength: Short){ try{ if(virt==null) virt=Virtualizer(0,sessionId); virt?.setStrength(strength); virt?.enabled=true }catch(e:Exception){} }
    fun release(){ try{ eq?.release(); bass?.release(); virt?.release()}catch(e:Exception){} }
}
