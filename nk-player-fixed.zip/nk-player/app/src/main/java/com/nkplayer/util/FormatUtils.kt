package com.nkplayer.util
import java.util.concurrent.TimeUnit
fun formatDuration(ms: Long): String{
    if(ms<=0) return "00:00"
    val s = TimeUnit.MILLISECONDS.toSeconds(ms)
    val h = s/3600; val m=(s%3600)/60; val sec=s%60
    return if(h>0) String.format("%d:%02d:%02d",h,m,sec) else String.format("%02d:%02d",m,sec)
}
fun formatSize(bytes: Long): String{
    if(bytes<=0) return "0 B"
    val units=arrayOf("B","KB","MB","GB")
    var b=bytes.toDouble(); var i=0
    while(b>=1024 && i<units.size-1){ b/=1024; i++}
    return String.format("%.1f %s",b,units[i])
}
fun String.isVideoExt(): Boolean{
    val v=setOf("mp4","mkv","avi","mov","wmv","flv","webm","mpeg","mpg","ts","m2ts","vob","3gp","ogv")
    return substringAfterLast('.', "").lowercase() in v
}
