package com.nkplayer.ui.home

import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.nkplayer.util.Perms
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.nkplayer.data.model.MediaItem
import com.nkplayer.ui.components.GlassCard
import com.nkplayer.ui.navigation.Route
import com.nkplayer.ui.theme.*
import com.nkplayer.util.formatDuration

@Composable
fun HomeScreen(nav: NavController, vm: HomeViewModel = hiltViewModel()){
    val videos by vm.videos.collectAsState()
    val audios by vm.audios.collectAsState()
    val query by vm.query.collectAsState()
    val loading by vm.isLoading.collectAsState()
    val palette = ThemeState.palette

    // Runtime media permission: without it MediaStore returns nothing
    val ctx = LocalContext.current
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){ vm.refresh() }
    LaunchedEffect(Unit){
        val missing = Perms.media.filter{ ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED }
        if(missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray())
    }

    Box(modifier=Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(BgBlack, BgSurface)))){
        Column(modifier=Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement=Arrangement.spacedBy(16.dp)){
            // Header
            Row(modifier=Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically){
                Column{
                    Text("NK PLAYER", style=MaterialTheme.typography.displaySmall.copy(color=palette.primary), maxLines=1)
                    Text("Ultimate Media Experience", style=MaterialTheme.typography.labelSmall.copy(color=TextSecondary))
                }
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    IconButton(onClick={ nav.navigate(Route.Studio.route)}){
                        Icon(Icons.Filled.Palette, contentDescription="Studio", tint=palette.primary)
                    }
                    IconButton(onClick={ nav.navigate(Route.Settings.route)}){
                        Icon(Icons.Filled.Settings, contentDescription="Settings", tint=TextSecondary)
                    }
                }
            }
            // Search
            OutlinedTextField(value=query, onValueChange={ vm.setQuery(it)}, modifier=Modifier.fillMaxWidth(), placeholder={ Text("Search videos, music, folders...")}, leadingIcon={ Icon(Icons.Filled.Search, null)}, singleLine=true, shape=RoundedCornerShape(16.dp))
            // Stats
            Row(modifier=Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(12.dp)){
                StatCard("${videos.size}", "Videos", palette.primary, Modifier.weight(1f))
                StatCard("${audios.size}", "Tracks", palette.accent, Modifier.weight(1f))
                StatCard("${videos.size+audios.size}", "Total", palette.secondary, Modifier.weight(1f))
            }
            // Quick actions
            LazyRow(horizontalArrangement=Arrangement.spacedBy(10.dp)){
                item{
                    QuickChip("All Videos", Icons.Filled.VideoLibrary, palette.primary){ nav.navigate(Route.Library.route)}
                }
                item{ QuickChip("Music", Icons.Filled.MusicNote, palette.accent){ nav.navigate(Route.AudioPlayer.route)} }
                item{ QuickChip("Studio", Icons.Filled.AutoAwesome, palette.secondary){ nav.navigate(Route.Studio.route)} }
                item{ QuickChip("Settings", Icons.Filled.Tune, TextSecondary){ nav.navigate(Route.Settings.route)} }
            }

            if(loading){
                repeat(3){ GlassCard(modifier=Modifier.fillMaxWidth().height(80.dp)){} }
            } else {
                // Continue Watching / Recent
                SectionHeader("Videos", "${vm.filteredVideos().size} items", palette.primary)
                if(vm.filteredVideos().isEmpty()){
                    EmptyState("No videos found", "Grant media permission or add files to device storage")
                } else {
                    MediaGrid(items=vm.filteredVideos().take(12), onClick={ item-> nav.navigate(Route.VideoPlayer.withUri(item.uri.toString())) })
                }

                SectionHeader("Music", "${vm.filteredAudios().size} tracks", palette.accent)
                if(vm.filteredAudios().isEmpty()){
                    EmptyState("No music found", "Add audio files to enjoy NK Player")
                } else {
                    vm.filteredAudios().take(8).forEach{ track->
                        GlassCard(modifier=Modifier.fillMaxWidth().clickable{ nav.navigate(Route.AudioPlayer.route)}, corner=16.dp){
                            Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(12.dp)){
                                Box(modifier=Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(palette.primary.copy(alpha=0.2f)), contentAlignment=Alignment.Center){
                                    Icon(Icons.Filled.MusicNote, null, tint=palette.primary)
                                }
                                Column(modifier=Modifier.weight(1f)){
                                    Text(track.title, maxLines=1, overflow=TextOverflow.Ellipsis, style=MaterialTheme.typography.bodyMedium.copy(color=TextPrimary))
                                    Text(track.artist ?: track.album ?: track.displayName, maxLines=1, overflow=TextOverflow.Ellipsis, style=MaterialTheme.typography.labelSmall)
                                }
                                Text(formatDuration(track.durationMs), style=MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(80.dp))
        }
    }
}

@Composable private fun StatCard(value:String, label:String, color: Color, mod: Modifier){
    GlassCard(modifier=mod, corner=16.dp){
        Text(value, style=MaterialTheme.typography.titleLarge.copy(color=color))
        Text(label, style=MaterialTheme.typography.labelSmall)
    }
}
@Composable private fun QuickChip(title:String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, onClick:()->Unit){
    Surface(shape=RoundedCornerShape(24.dp), color=color.copy(alpha=0.14f), modifier=Modifier.clickable(onClick=onClick)){
        Row(modifier=Modifier.padding(horizontal=14.dp, vertical=8.dp), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(6.dp)){
            Icon(icon, null, tint=color, modifier=Modifier.size(16.dp))
            Text(title, style=MaterialTheme.typography.labelMedium.copy(color=color))
        }
    }
}
@Composable private fun SectionHeader(title:String, subtitle:String, color: Color){
    Row(modifier=Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically){
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp), verticalAlignment=Alignment.CenterVertically){
            Box(Modifier.size(4.dp).clip(RoundedCornerShape(2.dp)).background(color))
            Text(title, style=MaterialTheme.typography.titleMedium)
        }
        Text(subtitle, style=MaterialTheme.typography.labelSmall)
    }
}
@Composable private fun EmptyState(title:String, subtitle:String){
    GlassCard(modifier=Modifier.fillMaxWidth(), corner=16.dp){
        Icon(Icons.Filled.VideoLibrary, null, tint=TextTertiary, modifier=Modifier.size(28.dp))
        Spacer(Modifier.height(8.dp))
        Text(title, style=MaterialTheme.typography.titleSmall)
        Text(subtitle, style=MaterialTheme.typography.bodySmall.copy(color=TextSecondary))
    }
}
@Composable private fun MediaGrid(items: List<MediaItem>, onClick:(MediaItem)->Unit){
    LazyVerticalGrid(columns=GridCells.Fixed(2), modifier=Modifier.heightIn(max=600.dp).fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(12.dp), verticalArrangement=Arrangement.spacedBy(12.dp), userScrollEnabled=false){
        items(items, key={ it.id}){ item->
            GlassCard(modifier=Modifier.clickable{ onClick(item)}, corner=16.dp){
                Box(modifier=Modifier.fillMaxWidth().height(90.dp).clip(RoundedCornerShape(12.dp)).background(BgSurface2), contentAlignment=Alignment.Center){
                    Icon(Icons.Filled.PlayCircle, null, tint=TextTertiary, modifier=Modifier.size(32.dp))
                    Box(modifier=Modifier.align(Alignment.BottomEnd).padding(6.dp).clip(RoundedCornerShape(6.dp)).background(Color.Black.copy(alpha=0.6f)).padding(horizontal=6.dp, vertical=2.dp)){
                        Text(formatDuration(item.durationMs), style=MaterialTheme.typography.labelSmall.copy(color=Color.White))
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(item.title, maxLines=1, overflow=TextOverflow.Ellipsis, style=MaterialTheme.typography.bodySmall.copy(color=TextPrimary))
                Text(item.folder ?: item.displayName, maxLines=1, overflow=TextOverflow.Ellipsis, style=MaterialTheme.typography.labelSmall)
            }
        }
    }
}
