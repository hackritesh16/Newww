package com.nkplayer.di

import android.content.Context
import androidx.room.Room
import com.nkplayer.data.local.db.NKDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module @InstallIn(SingletonComponent::class)
object AppModule{
    @Provides @Singleton fun provideDb(@ApplicationContext ctx: Context): NKDatabase =
        Room.databaseBuilder(ctx, NKDatabase::class.java, "nk.db").fallbackToDestructiveMigration().build()
    @Provides fun provideHistoryDao(db:NKDatabase)=db.historyDao()
    @Provides fun provideFavDao(db:NKDatabase)=db.favoriteDao()
    @Provides fun providePlaylistDao(db:NKDatabase)=db.playlistDao()
    @Provides fun provideBookmarkDao(db:NKDatabase)=db.bookmarkDao()
}
