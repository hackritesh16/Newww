package com.nkplayer.data.local.db
import androidx.room.Database
import androidx.room.RoomDatabase
import com.nkplayer.data.local.db.dao.*
import com.nkplayer.data.local.db.entity.*
@Database(entities=[HistoryEntity::class,FavoriteEntity::class,PlaylistEntity::class,PlaylistItemEntity::class,BookmarkEntity::class], version=1, exportSchema=false)
abstract class NKDatabase: RoomDatabase(){
    abstract fun historyDao(): HistoryDao
    abstract fun favoriteDao(): FavoriteDao
    abstract fun playlistDao(): PlaylistDao
    abstract fun bookmarkDao(): BookmarkDao
}
