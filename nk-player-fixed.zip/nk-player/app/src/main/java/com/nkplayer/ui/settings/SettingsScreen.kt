package com.nkplayer.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.nkplayer.ui.components.GlassCard
import com.nkplayer.ui.navigation.Route
import com.nkplayer.ui.theme.*

data class SettingSection(val title:String, val icon: ImageVector, val items: List<String>)

@Composable
fun SettingsScreen(nav: NavController){
    val sections = remember{ listOf(
        SettingSection("Appearance & Themes", Icons.Filled.Palette, listOf("Theme — NK Studio","Glass/Border/Blur","Light / Dark / AMOLED","Accent color")),
        SettingSection("Player Interface", Icons.Filled.Tune, listOf("Control layout","Gesture mapping","Double-tap seek","Lock overlay")),
        SettingSection("Video Playback", Icons.Filled.VideoSettings, listOf("Decoder — HW / SW","Aspect ratio","Playback speed 0.1x–16x","Brightness/Contrast/Saturation")),
        SettingSection("Audio Playback", Icons.Filled.MusicNote, listOf("Gapless / Crossfade","Pitch & Speed","Balance","Normalization")),
        SettingSection("Equalizer & Effects", Icons.Filled.Equalizer, listOf("10-band EQ","Presets","Bass Boost / Virtualizer","Custom profiles")),
        SettingSection("Subtitles & Languages", Icons.Filled.Subtitles, listOf("Auto-find local .srt","Font/size/color/outline","Delay sync","Multi-track")),
        SettingSection("Media Library", Icons.Filled.Folder, listOf("Auto scan","Manual folder (SAF)","MediaStore","Hidden/excluded folders")),
        SettingSection("Network & Streaming", Icons.Filled.Language, listOf("HTTP(S) / HLS / DASH","RTSP / RTMP (engine-dependent)","SMB/NAS/DLNA (if feasible)","M3U/M3U8 IPTV")),
        SettingSection("Gestures & Shortcuts", Icons.Filled.Gesture, listOf("Swipe brightness/volume","Keyboard shortcuts","Headphone unplug")),
        SettingSection("Notifications", Icons.Filled.Notifications, listOf("Background playback","Lock-screen controls","MediaSession")),
        SettingSection("Storage & Cache", Icons.Filled.Storage, listOf("Thumbnail cache","Clear history/cache","Storage usage")),
        SettingSection("Privacy & Security", Icons.Filled.Security, listOf("App lock (Biometric)","Clear history","No telemetry")),
        SettingSection("Accessibility", Icons.Filled.Accessibility, listOf("High contrast","Large controls","Screen reader")),
        SettingSection("Performance", Icons.Filled.Bolt, listOf("Hardware decode","Battery saver","Lazy rendering")),
        SettingSection("Advanced Engine", Icons.Filled.SettingsApplications, listOf("ExoPlayer tuning","Buffer/timeout","Retry policy")),
        SettingSection("About NK Player", Icons.Filled.Info, listOf("Version 1.0.0","Licenses","Diagnostics","Report issue")),
    )}
    var search by remember{ mutableStateOf("")}
    val filtered = if(search.isBlank()) sections else sections.filter{ it.title.contains(search, true) || it.items.any{ i-> i.contains(search,true)} }

    Box(modifier=Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(BgBlack, BgSurface)))){
        Column(modifier=Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)){
            Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(8.dp)){
                IconButton(onClick={ nav.popBackStack()}){ Icon(Icons.Filled.ArrowBack, null, tint=TextPrimary)}
                Text("Settings", style=MaterialTheme.typography.titleLarge)
                Spacer(Modifier.weight(1f))
                IconButton(onClick={ nav.navigate(Route.Studio.route)}){ Icon(Icons.Filled.AutoAwesome, null, tint=ThemeState.palette.primary)}
            }
            OutlinedTextField(value=search, onValueChange={ search=it}, modifier=Modifier.fillMaxWidth(), placeholder={ Text("Search settings...")}, leadingIcon={ Icon(Icons.Filled.Search, null)}, singleLine=true)
            LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp), modifier=Modifier.fillMaxSize()){
                items(filtered){ sec->
                    GlassCard(corner=16.dp){
                        Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(10.dp)){
                            Icon(sec.icon, null, tint=ThemeState.palette.primary)
                            Text(sec.title, style=MaterialTheme.typography.titleSmall)
                        }
                        Spacer(Modifier.height(8.dp))
                        sec.items.forEach{ item->
                            Row(modifier=Modifier.fillMaxWidth().clickable{}.padding(vertical=4.dp), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically){
                                Text(item, style=MaterialTheme.typography.bodySmall.copy(color=TextSecondary), modifier=Modifier.weight(1f))
                                Icon(Icons.Filled.ChevronRight, null, tint=TextTertiary, modifier=Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
