package com.nkplayer.playback

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PlayerManager @Inject constructor(@ApplicationContext private val ctx: Context){
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying
    private val _positionMs = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _positionMs
    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs

    fun connect(){
        if(controllerFuture!=null) return
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(ctx, token).buildAsync()
        controllerFuture?.addListener({
            controller = controllerFuture?.get()
            controller?.addListener(object: Player.Listener{
                override fun onIsPlayingChanged(v:Boolean){ _isPlaying.value=v }
                override fun onPlaybackStateChanged(s:Int){
                    _durationMs.value = controller?.duration?.coerceAtLeast(0) ?: 0
                }
            })
        }, MoreExecutors.directExecutor())
    }
    fun playUri(uri: Uri, title: String="Media"){
        val item = MediaItem.Builder().setUri(uri).setMediaId(uri.toString()).setMediaMetadata(
            androidx.media3.common.MediaMetadata.Builder().setTitle(title).build()
        ).build()
        controller?.setMediaItem(item)
        controller?.prepare()
        controller?.play()
    }
    fun playList(uris: List<Uri>){
        val items = uris.mapIndexed{ i,u-> MediaItem.Builder().setUri(u).setMediaId(u.toString()).build()}
        controller?.setMediaItems(items)
        controller?.prepare(); controller?.play()
    }
    fun togglePlayPause(){
        controller?.let{ if(it.isPlaying) it.pause() else it.play() }
    }
    fun seekTo(ms: Long){ controller?.seekTo(ms) }
    fun seekBy(deltaMs: Long){
        controller?.let{ it.seekTo((it.currentPosition + deltaMs).coerceAtLeast(0)) }
    }
    fun setSpeed(s: Float){ controller?.setPlaybackSpeed(s) }
    fun next(){ controller?.seekToNextMediaItem() }
    fun prev(){ controller?.seekToPreviousMediaItem() }
    fun release(){ MediaController.releaseFuture(controllerFuture!!); controllerFuture=null; controller=null }
    fun getController(): MediaController? = controller
}
