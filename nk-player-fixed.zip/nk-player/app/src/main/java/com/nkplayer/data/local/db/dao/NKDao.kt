package com.nkplayer.data.local.db.dao
import androidx.room.*
import com.nkplayer.data.local.db.entity.*
import kotlinx.coroutines.flow.Flow

@Dao interface HistoryDao {
    @Query("SELECT * FROM history ORDER BY lastPlayedAt DESC LIMIT :limit") fun recent(limit:Int): Flow<List<HistoryEntity>>
    @Query("SELECT * FROM history ORDER BY lastPlayedAt DESC") fun all(): Flow<List<HistoryEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(e: HistoryEntity)
    @Query("DELETE FROM history WHERE mediaId=:id") suspend fun delete(id:Long)
    @Query("DELETE FROM history") suspend fun clear()
}
@Dao interface FavoriteDao {
    @Query("SELECT * FROM favorites") fun all(): Flow<List<FavoriteEntity>>
    @Insert(onConflict= OnConflictStrategy.REPLACE) suspend fun add(e: FavoriteEntity)
    @Query("DELETE FROM favorites WHERE mediaId=:id") suspend fun remove(id:Long)
    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE mediaId=:id)") suspend fun isFav(id:Long): Boolean
    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE mediaId=:id)") fun isFavFlow(id:Long): Flow<Boolean>
}
@Dao interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY createdAt DESC") fun playlists(): Flow<List<PlaylistEntity>>
    @Insert(onConflict= OnConflictStrategy.REPLACE) suspend fun insert(p: PlaylistEntity): Long
    @Query("DELETE FROM playlists WHERE id=:id") suspend fun deletePlaylist(id:Long)
    @Query("SELECT * FROM playlist_items WHERE playlistId=:pid ORDER BY position") fun items(pid:Long): Flow<List<PlaylistItemEntity>>
    @Insert(onConflict= OnConflictStrategy.REPLACE) suspend fun addItem(e: PlaylistItemEntity)
    @Query("DELETE FROM playlist_items WHERE playlistId=:pid AND mediaId=:mid") suspend fun removeItem(pid:Long, mid:Long)
}
@Dao interface BookmarkDao {
    @Query("SELECT * FROM bookmarks WHERE mediaId=:mid ORDER BY positionMs") fun forMedia(mid:Long): Flow<List<BookmarkEntity>>
    @Insert suspend fun insert(e: BookmarkEntity): Long
    @Query("DELETE FROM bookmarks WHERE id=:id") suspend fun delete(id:Long)
}
