package com.nkplayer.ui.theme

import androidx.compose.ui.graphics.Color

// AMOLED base
val BgBlack = Color(0xFF080A10)
val BgSurface = Color(0xFF11131A)
val BgSurface2 = Color(0xFF1A1D27)
val GlassBg = Color(0x1AFFFFFF)
val GlassBorder = Color(0x22FFFFFF)
val TextPrimary = Color(0xFFF2F2F7)
val TextSecondary = Color(0xFF9AA0B3)
val TextTertiary = Color(0xFF6B7080)

// Neon palettes
data class NeonPalette(val primary: Color, val secondary: Color, val accent: Color, val glow: Color)
val NeonBlue = NeonPalette(Color(0xFF00D4FF), Color(0xFF0066FF), Color(0xFF00FFD1), Color(0xFF00D4FF))
val CyberPurple = NeonPalette(Color(0xFF9D4EDD), Color(0xFF5A189A), Color(0xFFC77DFF), Color(0xFF9D4EDD))
val Emerald = NeonPalette(Color(0xFF00E676), Color(0xFF00B248), Color(0xFF69F0AE), Color(0xFF00E676))
val Crimson = NeonPalette(Color(0xFFFF1744), Color(0xFFD50000), Color(0xFFFF5252), Color(0xFFFF1744))
val IceCyan = NeonPalette(Color(0xFF18FFFF), Color(0xFF00B8D4), Color(0xFF84FFFF), Color(0xFF18FFFF))
val GoldenAmber = NeonPalette(Color(0xFFFFAB00), Color(0xFFFF6D00), Color(0xFFFFD740), Color(0xFFFFAB00))
val Aurora = NeonPalette(Color(0xFF00F5A0), Color(0xFF00D9F5), Color(0xFFFF7AC1), Color(0xFF00F5A0))
val Synthwave = NeonPalette(Color(0xFFFF00E5), Color(0xFF00F0FF), Color(0xFFFFD600), Color(0xFFFF00E5))
val CurrentNeon = NeonBlue // default, overridden by DataStore

val ErrorRed = Color(0xFFFF3B30)
val SuccessGreen = Color(0xFF30D158)
