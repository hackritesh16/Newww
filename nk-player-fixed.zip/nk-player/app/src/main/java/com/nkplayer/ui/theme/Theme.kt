package com.nkplayer.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color

private fun neonScheme(p: NeonPalette, isAmoled: Boolean) = darkColorScheme(
    primary = p.primary, onPrimary = Color.White,
    secondary = p.secondary, onSecondary = Color.White,
    tertiary = p.accent, onTertiary = Color.Black,
    background = if (isAmoled) BgBlack else BgSurface,
    surface = if (isAmoled) BgBlack else BgSurface,
    surfaceVariant = BgSurface2,
    onBackground = TextPrimary, onSurface = TextPrimary,
    outline = GlassBorder, error = ErrorRed
)

@Composable
fun NKPlayerTheme(
    palette: NeonPalette = NeonBlue,
    isAmoled: Boolean = true,
    content: @Composable () -> Unit
) {
    val scheme = neonScheme(palette, isAmoled)
    MaterialTheme(colorScheme = scheme, typography = NKTypography, content = content)
}

// Runtime theme state holder (observed from DataStore in real app)
object ThemeState {
    var palette by mutableStateOf<NeonPalette>(NeonBlue)
    var isAmoled by mutableStateOf(true)
    var glassAlpha by mutableStateOf(0.12f)
    var glowStrength by mutableStateOf(0.6f)
    var cornerRadius by mutableStateOf(20)
    fun setPalette(name: String) {
        palette = when(name){
            "CyberPurple"->CyberPurple; "Emerald"->Emerald; "Crimson"->Crimson
            "IceCyan"->IceCyan; "GoldenAmber"->GoldenAmber; "Aurora"->Aurora; "Synthwave"->Synthwave
            else->NeonBlue
        }
    }
}
