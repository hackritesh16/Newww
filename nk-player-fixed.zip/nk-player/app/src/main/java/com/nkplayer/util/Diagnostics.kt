package com.nkplayer.util

import android.content.Context
import android.os.Build

object Diagnostics {
    fun info(ctx: Context): String = buildString{
        appendLine("NK Player v1.0.0 (1)")
        appendLine("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) — ${Build.MANUFACTURER} ${Build.MODEL}")
        appendLine("ABI: ${Build.SUPPORTED_ABIS.joinToString()}")
        appendLine("Package: ${ctx.packageName}")
    }
}
