package com.nkplayer.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.nkplayer.ui.theme.NeonBlue
import kotlin.random.Random

@Composable
fun AudioVisualizer(isPlaying: Boolean, color: Color = NeonBlue.primary, modifier: Modifier=Modifier){
    val bars = remember{ List(20){ Random.nextFloat()} }
    val inf = rememberInfiniteTransition(label="viz")
    val anims = List(20){ i->
        inf.animateFloat(initialValue=4f, targetValue=28f+bars[i]*24f, animationSpec=infiniteRepeatable(animation=tween(280+ i*30, easing= LinearEasing), repeatMode=RepeatMode.Reverse), label="b$i")
    }
    Row(modifier=modifier.height(36.dp), horizontalArrangement=Arrangement.spacedBy(3.dp)){
        anims.forEach{ a->
            val h = if(isPlaying) a.value.dp else 6.dp
            Box(modifier=Modifier.width(4.dp).height(h).clip(RoundedCornerShape(2.dp)).background(color))
        }
    }
}
