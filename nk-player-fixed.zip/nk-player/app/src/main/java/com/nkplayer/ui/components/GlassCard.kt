package com.nkplayer.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nkplayer.ui.theme.GlassBg
import com.nkplayer.ui.theme.GlassBorder
import com.nkplayer.ui.theme.TextPrimary

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    corner: Dp = 20.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
){
    val shape = RoundedCornerShape(corner)
    val cardMod = modifier.clip(shape).background(GlassBg).border(BorderStroke(1.dp, GlassBorder), shape)
    if(onClick!=null){
        Surface(modifier=cardMod, shape=shape, color=Color.Transparent, onClick=onClick, content={ Column(modifier=Modifier.padding(16.dp), content=content)})
    } else {
        Box(modifier=cardMod.padding(16.dp)){ Column(content=content) }
    }
}

@Composable fun NeonDivider(modifier: Modifier=Modifier, color: Color = GlassBorder){
    Box(modifier=modifier.fillMaxWidth().height(1.dp).background(color))
}

@Composable fun GlowBadge(text: String, color: Color){
    Surface(shape=RoundedCornerShape(8.dp), color=color.copy(alpha=0.18f), contentColor=color){
        Text(text=text, modifier=Modifier.padding(horizontal=8.dp, vertical=4.dp), style=MaterialTheme.typography.labelSmall.copy(color=color))
    }
}
