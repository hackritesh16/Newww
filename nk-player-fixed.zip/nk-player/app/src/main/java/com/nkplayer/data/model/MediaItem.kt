package com.nkplayer.data.model

import android.net.Uri

enum class MediaType { VIDEO, AUDIO, UNKNOWN }

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val displayName: String,
    val title: String,
    val artist: String? = null,
    val album: String? = null,
    val albumId: Long? = null,
    val durationMs: Long = 0,
    val sizeBytes: Long = 0,
    val dateAdded: Long = 0,
    val dateModified: Long = 0,
    val mimeType: String? = null,
    val path: String? = null,
    val type: MediaType = MediaType.UNKNOWN,
    val width: Int = 0,
    val height: Int = 0,
    val bitrate: Int = 0,
    val artworkUri: Uri? = null,
    val folder: String? = null,
    val isFavorite: Boolean = false,
    val lastPlayedAt: Long? = null,
    val lastPositionMs: Long = 0,
    val playCount: Int = 0,
)
