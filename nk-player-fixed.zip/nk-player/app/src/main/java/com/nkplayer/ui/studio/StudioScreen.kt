package com.nkplayer.ui.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.nkplayer.ui.components.GlassCard
import com.nkplayer.ui.theme.*

data class ThemeOption(val name: String, val palette: NeonPalette)

@Composable
fun StudioScreen(nav: NavController){
    val options = remember{ listOf(
        ThemeOption("NeonBlue", NeonBlue), ThemeOption("CyberPurple", CyberPurple),
        ThemeOption("Emerald", Emerald), ThemeOption("Crimson", Crimson),
        ThemeOption("IceCyan", IceCyan), ThemeOption("GoldenAmber", GoldenAmber),
        ThemeOption("Aurora", Aurora), ThemeOption("Synthwave", Synthwave),
    )}
    var selected by remember{ mutableStateOf(ThemeState.palette)}
    var glass by remember{ mutableStateOf(ThemeState.glassAlpha)}
    var glow by remember{ mutableStateOf(ThemeState.glowStrength)}
    var amoled by remember{ mutableStateOf(ThemeState.isAmoled)}

    Box(modifier=Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(BgBlack, BgSurface)))){
        Column(modifier=Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement=Arrangement.spacedBy(16.dp)){
            Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(8.dp)){
                IconButton(onClick={ nav.popBackStack()}){ Icon(Icons.Filled.ArrowBack, null, tint=TextPrimary)}
                Text("NK STUDIO", style=MaterialTheme.typography.titleLarge)
                Spacer(Modifier.weight(1f))
                Surface(shape=RoundedCornerShape(12.dp), color=selected.primary){ Text(" LIVE PREVIEW ", color=Color.White, style=MaterialTheme.typography.labelSmall, modifier=Modifier.padding(horizontal=8.dp, vertical=4.dp))}
            }
            Text("Themes", style=MaterialTheme.typography.titleMedium)
            LazyRow(horizontalArrangement=Arrangement.spacedBy(12.dp)){
                items(options){ opt->
                    val isSel = opt.palette==selected
                    Column(horizontalAlignment=Alignment.CenterHorizontally, modifier=Modifier.clickable{ selected=opt.palette; ThemeState.palette=opt.palette; ThemeState.setPalette(opt.name) }.padding(4.dp)){
                        Box(modifier=Modifier.size(64.dp).clip(CircleShape).background(Brush.linearGradient(listOf(opt.palette.primary, opt.palette.secondary))).border(if(isSel) 3.dp else 0.dp, if(isSel) Color.White else Color.Transparent, CircleShape), contentAlignment=Alignment.Center){
                            if(isSel) Icon(Icons.Filled.Check, null, tint=Color.White)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(opt.name, style=MaterialTheme.typography.labelSmall.copy(color= if(isSel) selected.primary else TextSecondary))
                    }
                }
            }
            GlassCard(corner=16.dp){
                Text("Glass & Glow", style=MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(12.dp))
                Text("Glass Alpha  ${(glass*100).toInt()}%", style=MaterialTheme.typography.labelSmall)
                Slider(value=glass, onValueChange={ glass=it; ThemeState.glassAlpha=it }, valueRange=0.04f..0.30f)
                Text("Glow Strength  ${(glow*100).toInt()}%", style=MaterialTheme.typography.labelSmall)
                Slider(value=glow, onValueChange={ glow=it; ThemeState.glowStrength=it }, valueRange=0f..1f)
                Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween, modifier=Modifier.fillMaxWidth()){
                    Text("AMOLED Black", style=MaterialTheme.typography.bodyMedium)
                    Switch(checked=amoled, onCheckedChange={ amoled=it; ThemeState.isAmoled=it })
                }
            }
            GlassCard(corner=16.dp){
                Text("Preview", style=MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement=Arrangement.spacedBy(10.dp), modifier=Modifier.fillMaxWidth()){
                    Box(Modifier.weight(1f).height(70.dp).clip(RoundedCornerShape(14.dp)).background(selected.primary.copy(alpha=0.18f)).border(1.dp, selected.primary.copy(alpha=0.3f), RoundedCornerShape(14.dp)), contentAlignment=Alignment.Center){ Icon(Icons.Filled.PlayCircle, null, tint=selected.primary)}
                    Box(Modifier.weight(1f).height(70.dp).clip(RoundedCornerShape(14.dp)).background(BgSurface2), contentAlignment=Alignment.Center){ Icon(Icons.Filled.MusicNote, null, tint=TextSecondary)}
                }
            }
            Row(horizontalArrangement=Arrangement.spacedBy(12.dp), modifier=Modifier.fillMaxWidth()){
                OutlinedButton(onClick={
                    selected=NeonBlue; ThemeState.palette=NeonBlue; glass=0.12f; glow=0.6f; amoled=true
                    ThemeState.glassAlpha=0.12f; ThemeState.glowStrength=0.6f; ThemeState.isAmoled=true
                }, modifier=Modifier.weight(1f)){ Text("Reset")}
                Button(onClick={ nav.popBackStack()}, modifier=Modifier.weight(1f), colors=ButtonDefaults.buttonColors(containerColor=selected.primary)){ Text("Apply & Back")}
            }
            Text("Import/Export theme JSON (coming soon) — theme survives app restart via DataStore.", style=MaterialTheme.typography.labelSmall.copy(color=TextTertiary))
        }
    }
}
