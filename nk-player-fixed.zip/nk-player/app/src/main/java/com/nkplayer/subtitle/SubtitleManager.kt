package com.nkplayer.subtitle

import android.net.Uri
import androidx.media3.common.MediaItem
import java.io.File

object SubtitleManager {
    data class SubTrack(val uri: Uri, val lang: String, val label: String, val mime: String)

    fun mimeForExt(ext:String): String = when(ext.lowercase()){
        "srt"-> "application/x-subrip"; "vtt"-> "text/vtt"; "ass","ssa"-> "text/x-ssa"; "sub"-> "application/x-subrip"; else-> "application/x-subrip"
    }

    fun findLocalSubs(videoPath:String): List<File>{
        val base = File(videoPath).parentFile ?: return emptyList()
        val nameWithoutExt = File(videoPath).nameWithoutExtension
        return base.listFiles { f-> f.extension.lowercase() in setOf("srt","ass","ssa","vtt","sub") && f.nameWithoutExtension.startsWith(nameWithoutExt) }?.toList() ?: emptyList()
    }

    fun buildMediaItemWithSubs(videoUri: Uri, subs: List<SubTrack>): MediaItem {
        val configs = subs.map{ s->
            MediaItem.SubtitleConfiguration.Builder(s.uri).setMimeType(s.mime).setLanguage(s.lang).setLabel(s.label).setSelectionFlags(0).build()
        }
        return MediaItem.Builder().setUri(videoUri).setSubtitleConfigurations(configs).build()
    }
}
