package com.nkplayer.data.local.db.entity
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "favorites")
data class FavoriteEntity(@PrimaryKey val mediaId: Long, val addedAt: Long = System.currentTimeMillis())
