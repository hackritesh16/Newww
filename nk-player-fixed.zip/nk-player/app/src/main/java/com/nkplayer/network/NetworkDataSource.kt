package com.nkplayer.network

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes

object NetworkDataSource {
    fun isNetworkUrl(s: String): Boolean = s.startsWith("http://") || s.startsWith("https://") || s.startsWith("rtsp://") || s.startsWith("rtmp://")
    fun isHls(url:String): Boolean = url.contains(".m3u8", true)
    fun isDash(url:String): Boolean = url.contains(".mpd", true)
    fun buildMediaItem(url:String, title:String="Stream"): MediaItem {
        val builder = MediaItem.Builder().setUri(Uri.parse(url)).setMediaId(url)
        val mime = when{ isHls(url)-> MimeTypes.APPLICATION_M3U8; isDash(url)-> MimeTypes.APPLICATION_MPD; url.endsWith(".mp3",true)-> MimeTypes.AUDIO_MPEG; else-> null }
        if(mime!=null) builder.setMimeType(mime)
        builder.setMediaMetadata(androidx.media3.common.MediaMetadata.Builder().setTitle(title).build())
        return builder.build()
    }
    // SMB/NAS/DLNA are architecture-ready via ExoPlayer extension points; SMB needs jcifs-ng/Shizuku scope.
    // IPTV M3U/M3U8 parsing: read playlist text, extract #EXTINF lines.
    fun parseM3U(content:String): List<String> = content.lines().map{ it.trim()}.filter{ it.isNotEmpty() && !it.startsWith("#")}
}
