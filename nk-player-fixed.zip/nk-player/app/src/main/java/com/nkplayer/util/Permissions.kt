package com.nkplayer.util
import android.Manifest
import android.os.Build
object Perms{
    val media = if(Build.VERSION.SDK_INT>=33) arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_IMAGES)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
}
