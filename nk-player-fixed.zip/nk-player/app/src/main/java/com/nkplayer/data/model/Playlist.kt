package com.nkplayer.data.model
data class Playlist(val id: Long, val name: String, val itemIds: List<Long> = emptyList(), val createdAt: Long = System.currentTimeMillis(), val artworkUri: String? = null)
data class QueueItem(val mediaId: Long, val position: Int)
