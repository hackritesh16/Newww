package com.nkplayer.ui.player

import android.app.Activity
import android.content.pm.ActivityInfo
import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.navigation.NavController
import com.nkplayer.ui.theme.ThemeState
import com.nkplayer.ui.theme.*
import com.nkplayer.util.formatDuration
import kotlinx.coroutines.delay

@Composable
fun VideoPlayerScreen(nav: NavController, uriStr: String){
    val ctx = LocalContext.current
    val activity = ctx as? Activity
    var showControls by remember{ mutableStateOf(true)}
    var speed by remember{ mutableStateOf(1f)}
    var isLocked by remember{ mutableStateOf(false)}
    var exoPlayer by remember{ mutableStateOf<ExoPlayer?>(null)}
    var isPlaying by remember{ mutableStateOf(false)}
    var position by remember{ mutableStateOf(0L)}
    var duration by remember{ mutableStateOf(0L)}

    // Auto-hide controls
    LaunchedEffect(showControls, isPlaying){
        if(showControls && isPlaying){ delay(3000); showControls=false }
    }

    Box(modifier=Modifier.fillMaxSize().background(Color.Black).clickable{ if(!isLocked) showControls=!showControls }){
        AndroidView(factory={ c->
            PlayerView(c).apply{
                layoutParams=FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                useController=false
                exoPlayer = ExoPlayer.Builder(c).build().also{ p->
                    p.addListener(object: Player.Listener{
                        override fun onIsPlayingChanged(v:Boolean){ isPlaying=v }
                        override fun onPlaybackStateChanged(s:Int){ duration=p.duration.coerceAtLeast(0) }
                    })
                    if(uriStr.isNotBlank()){
                        val item=androidx.media3.common.MediaItem.fromUri(Uri.parse(uriStr))
                        p.setMediaItem(item); p.prepare(); p.play()
                    }
                }
                player=exoPlayer
            }
        }, modifier=Modifier.fillMaxSize())

        // Top bar
        AnimatedVisibility(visible=showControls, enter=fadeIn(), exit=fadeOut(), modifier=Modifier.align(Alignment.TopCenter)){
            Row(modifier=Modifier.fillMaxWidth().background(Color.Black.copy(alpha=0.45f)).padding(12.dp), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically){
                IconButton(onClick={ exoPlayer?.release(); nav.popBackStack()}){
                    Icon(Icons.Filled.ArrowBack, null, tint=Color.White)
                }
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    IconButton(onClick={
                        activity?.requestedOrientation = if(activity?.requestedOrientation== ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    }){ Icon(Icons.Filled.ScreenRotation, null, tint=Color.White)}
                    IconButton(onClick={ isLocked=!isLocked}){ Icon(if(isLocked) Icons.Filled.Lock else Icons.Filled.LockOpen, null, tint=Color.White)}
                    IconButton(onClick={
                        // PiP placeholder — uses system PiP when available
                        if(android.os.Build.VERSION.SDK_INT>=26){ try{ activity?.enterPictureInPictureMode(android.app.PictureInPictureParams.Builder().build()) }catch(e:Exception){} }
                    }){ Icon(Icons.Filled.PictureInPictureAlt, null, tint=Color.White)}
                }
            }
        }

        // Center controls
        AnimatedVisibility(visible=showControls && !isLocked, enter=fadeIn(), exit=fadeOut(), modifier=Modifier.align(Alignment.Center)){
            Row(horizontalArrangement=Arrangement.spacedBy(28.dp), verticalAlignment=Alignment.CenterVertically){
                IconButton(onClick={ exoPlayer?.seekTo((exoPlayer!!.currentPosition-10000).coerceAtLeast(0))}, modifier=Modifier.size(48.dp).clip(CircleShape).background(Color.White.copy(alpha=0.15f))){
                    Icon(Icons.Filled.Replay10, null, tint=Color.White)
                }
                IconButton(onClick={ if(exoPlayer?.isPlaying==true) exoPlayer?.pause() else exoPlayer?.play()}, modifier=Modifier.size(64.dp).clip(CircleShape).background(ThemeState.palette.primary)){
                    Icon(if(isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint=Color.White, modifier=Modifier.size(32.dp))
                }
                IconButton(onClick={ exoPlayer?.seekTo(exoPlayer!!.currentPosition+10000)}, modifier=Modifier.size(48.dp).clip(CircleShape).background(Color.White.copy(alpha=0.15f))){
                    Icon(Icons.Filled.Forward10, null, tint=Color.White)
                }
            }
        }

        // Bottom bar
        AnimatedVisibility(visible=showControls && !isLocked, enter=fadeIn(), exit=fadeOut(), modifier=Modifier.align(Alignment.BottomCenter)){
            Column(modifier=Modifier.fillMaxWidth().background(Color.Black.copy(alpha=0.55f)).padding(12.dp), verticalArrangement=Arrangement.spacedBy(8.dp)){
                // Seek
                var sliderPos by remember{ mutableStateOf(0f)}
                LaunchedEffect(isPlaying){
                    while(true){
                        exoPlayer?.let{ position=it.currentPosition; duration=it.duration.coerceAtLeast(0); if(duration>0) sliderPos= position.toFloat()/duration }
                        delay(400)
                    }
                }
                Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    Text(formatDuration(position), color=Color.White, style=MaterialTheme.typography.labelSmall)
                    Slider(value=sliderPos, onValueChange={ sliderPos=it }, onValueChangeFinished={ exoPlayer?.seekTo((sliderPos*duration).toLong())}, modifier=Modifier.weight(1f), colors=SliderDefaults.colors(activeTrackColor=ThemeState.palette.primary))
                    Text(formatDuration(duration), color=Color.White, style=MaterialTheme.typography.labelSmall)
                }
                Row(modifier=Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically){
                    Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){
                        listOf(0.5f,1f,1.5f,2f).forEach{ s->
                            FilterChip(selected=s==speed, onClick={ speed=s; exoPlayer?.setPlaybackSpeed(s)}, label={ Text("${s}x", style=MaterialTheme.typography.labelSmall)}, colors=FilterChipDefaults.filterChipColors(selectedContainerColor=ThemeState.palette.primary))
                        }
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){
                        IconButton(onClick={ exoPlayer?.let{ it.volume=(it.volume-0.1f).coerceIn(0f,1f)}}){ Icon(Icons.Filled.VolumeDown, null, tint=Color.White)}
                        IconButton(onClick={ exoPlayer?.let{ it.volume=(it.volume+0.1f).coerceIn(0f,1f)}}){ Icon(Icons.Filled.VolumeUp, null, tint=Color.White)}
                    }
                }
            }
        }

        if(isLocked){
            Box(modifier=Modifier.align(Alignment.CenterEnd).padding(16.dp).clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(alpha=0.5f)).clickable{ isLocked=false}.padding(12.dp)){
                Icon(Icons.Filled.Lock, null, tint=Color.White)
            }
        }
    }
    BackHandler{ exoPlayer?.release(); nav.popBackStack() }
    DisposableEffect(Unit){ onDispose{ exoPlayer?.release() } }
}
