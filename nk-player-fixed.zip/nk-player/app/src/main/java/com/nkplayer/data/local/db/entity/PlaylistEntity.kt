package com.nkplayer.data.local.db.entity
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "playlists")
data class PlaylistEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val createdAt: Long = System.currentTimeMillis())
@Entity(tableName = "playlist_items", primaryKeys = ["playlistId","mediaId"])
data class PlaylistItemEntity(val playlistId: Long, val mediaId: Long, val position: Int, val uri: String, val title: String)
