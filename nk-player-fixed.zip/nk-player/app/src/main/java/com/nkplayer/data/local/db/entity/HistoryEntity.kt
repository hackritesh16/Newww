package com.nkplayer.data.local.db.entity
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "history")
data class HistoryEntity(@PrimaryKey val mediaId: Long, val title: String, val artist: String?, val uri: String, val type: String, val lastPositionMs: Long = 0, val durationMs: Long = 0, val lastPlayedAt: Long = System.currentTimeMillis(), val playCount: Int = 1)
