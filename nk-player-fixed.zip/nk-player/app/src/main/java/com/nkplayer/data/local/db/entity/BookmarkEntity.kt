package com.nkplayer.data.local.db.entity
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "bookmarks")
data class BookmarkEntity(@PrimaryKey(autoGenerate = true) val id: Long=0, val mediaId: Long, val positionMs: Long, val label: String, val createdAt: Long = System.currentTimeMillis())
