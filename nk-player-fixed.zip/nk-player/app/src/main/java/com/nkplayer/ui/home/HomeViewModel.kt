package com.nkplayer.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nkplayer.data.model.MediaItem
import com.nkplayer.data.repository.MediaRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(private val repo: MediaRepository): ViewModel(){
    private val _videos = MutableStateFlow<List<MediaItem>>(emptyList())
    val videos: StateFlow<List<MediaItem>> = _videos
    private val _audios = MutableStateFlow<List<MediaItem>>(emptyList())
    val audios: StateFlow<List<MediaItem>> = _audios
    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query
    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading
    val recentHistory = repo.recentHistory(20)

    init { refresh() }
    fun refresh(){
        viewModelScope.launch{
            _isLoading.value=true
            _videos.value = runCatching{ repo.videos()}.getOrDefault(emptyList())
            _audios.value = runCatching{ repo.audios()}.getOrDefault(emptyList())
            _isLoading.value=false
        }
    }
    fun setQuery(q:String){ _query.value=q }

    fun filteredVideos(): List<MediaItem>{
        val q=_query.value.lowercase().trim()
        val all=_videos.value
        return if(q.isEmpty()) all else all.filter{ it.title.lowercase().contains(q) || it.displayName.lowercase().contains(q) || (it.folder?.lowercase()?.contains(q)==true)}
    }
    fun filteredAudios(): List<MediaItem>{
        val q=_query.value.lowercase().trim()
        val all=_audios.value
        return if(q.isEmpty()) all else all.filter{ it.title.lowercase().contains(q) || (it.artist?.lowercase()?.contains(q)==true) || (it.album?.lowercase()?.contains(q)==true)}
    }
}
