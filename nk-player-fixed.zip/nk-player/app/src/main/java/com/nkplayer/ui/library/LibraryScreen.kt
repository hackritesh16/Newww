package com.nkplayer.ui.library

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.nkplayer.data.model.MediaItem
import com.nkplayer.ui.components.GlassCard
import com.nkplayer.ui.home.HomeViewModel
import com.nkplayer.ui.navigation.Route
import com.nkplayer.ui.theme.*
import com.nkplayer.util.formatDuration
import com.nkplayer.util.formatSize

@Composable
fun LibraryScreen(nav: NavController, vm: HomeViewModel = hiltViewModel()){
    val videos by vm.videos.collectAsState()
    val audios by vm.audios.collectAsState()
    var tab by remember{ mutableStateOf(0)}
    var sortBy by remember{ mutableStateOf("Date")}

    Box(modifier=Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(BgBlack, BgSurface)))){
        Column(modifier=Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)){
            Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(8.dp)){
                IconButton(onClick={ nav.popBackStack()}){ Icon(Icons.Filled.ArrowBack, null, tint=TextPrimary)}
                Text("Library", style=MaterialTheme.typography.titleLarge)
            }
            TabRow(selectedTabIndex=tab, containerColor= BgSurface2, contentColor= TextPrimary){
                Tab(selected=tab==0, onClick={ tab=0}, text={ Text("Videos (${videos.size})")})
                Tab(selected=tab==1, onClick={ tab=1}, text={ Text("Music (${audios.size})")})
                Tab(selected=tab==2, onClick={ tab=2}, text={ Text("Folders")})
            }
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                listOf("Date","Name","Size","Duration").forEach{ s->
                    FilterChip(selected=sortBy==s, onClick={ sortBy=s}, label={ Text(s)}, colors=FilterChipDefaults.filterChipColors(selectedContainerColor=ThemeState.palette.primary))
                }
            }
            val list: List<MediaItem> = when(tab){
                0 -> when(sortBy){ "Name"-> videos.sortedBy{ it.title.lowercase()} ; "Size"-> videos.sortedByDescending{ it.sizeBytes} ; "Duration"-> videos.sortedByDescending{ it.durationMs} else-> videos }
                1 -> when(sortBy){ "Name"-> audios.sortedBy{ it.title.lowercase()} ; "Size"-> audios.sortedByDescending{ it.sizeBytes} else-> audios }
                else -> emptyList()
            }
            if(tab==2){
                val folders = (videos+audios).mapNotNull{ it.folder}.groupBy{ it}.toList().sortedByDescending{ it.second.size }
                LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){
                    items(folders){ (name, items)->
                        GlassCard(modifier=Modifier.fillMaxWidth().clickable{}, corner=16.dp){
                            Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(12.dp)){
                                Box(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(ThemeState.palette.primary.copy(alpha=0.18f)), contentAlignment=Alignment.Center){ Icon(Icons.Filled.Folder, null, tint=ThemeState.palette.primary)}
                                Column(Modifier.weight(1f)){ Text(name, style=MaterialTheme.typography.bodyMedium); Text("${items.size} files", style=MaterialTheme.typography.labelSmall.copy(color=TextSecondary))}
                                Icon(Icons.Filled.ChevronRight, null, tint=TextTertiary)
                            }
                        }
                    }
                }
            } else {
                if(list.isEmpty()){
                    Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center){ Text("No items", color=TextSecondary)}
                } else {
                    LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){
                        items(list, key={ it.id}){ item->
                            GlassCard(modifier=Modifier.fillMaxWidth().clickable{
                                if(item.type.name=="VIDEO") nav.navigate(Route.VideoPlayer.withUri(item.uri.toString())) else nav.navigate(Route.AudioPlayer.route)
                            }, corner=14.dp){
                                Row(horizontalArrangement=Arrangement.spacedBy(12.dp), verticalAlignment=Alignment.CenterVertically){
                                    Box(Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)).background(BgSurface2), contentAlignment=Alignment.Center){
                                        Icon(if(item.type.name=="VIDEO") Icons.Filled.Movie else Icons.Filled.MusicNote, null, tint=TextSecondary)
                                    }
                                    Column(Modifier.weight(1f)){
                                        Text(item.title, style=MaterialTheme.typography.bodyMedium, maxLines=1)
                                        Text("${item.artist ?: item.folder ?: ""} • ${formatDuration(item.durationMs)} • ${formatSize(item.sizeBytes)}", style=MaterialTheme.typography.labelSmall.copy(color=TextSecondary), maxLines=1)
                                    }
                                    IconButton(onClick={}){ Icon(Icons.Filled.MoreVert, null, tint=TextTertiary, modifier=Modifier.size(18.dp))}
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
